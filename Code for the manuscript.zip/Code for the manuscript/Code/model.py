import math
import numpy
import torch
import torch.nn as nn
import torch.nn.functional as F

from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module

class GraphAttentionLayer(nn.Module):
    def __init__(self, in_features, out_features, dropout, alpha, batchsize, concat=True):
        super(GraphAttentionLayer, self).__init__()
        self.dropout = dropout
        self.in_features = in_features
        self.out_features = out_features
        self.alpha = alpha
        self.concat = concat

        self.W = nn.Parameter(torch.empty(size=(in_features, out_features))).cuda()
        nn.init.xavier_uniform_(self.W.data, gain=1.414).cuda()
        self.a = nn.Parameter(
            torch.empty(size=(out_features, 2 * out_features, 1))).cuda()
        nn.init.xavier_uniform_(self.a.data, gain=1.414).cuda()

        self.leakyrelu = nn.LeakyReLU(self.alpha)

    def forward(self, h, adj, batchsize):
        Wh = torch.matmul(h, self.W)
        a_input = self._prepare_attentional_mechanism_input(Wh, batchsize=batchsize)
        e = self.leakyrelu(torch.matmul(a_input, self.a).squeeze(3))

        zero_vec = -9e15 * torch.ones_like(e)
        attention = torch.where(adj != 0, e, zero_vec)
        attention = F.softmax(attention, dim=2)
        attention = F.dropout(attention, self.dropout, training=self.training)
        h_prime = torch.einsum('bij,bjd->bid', [Wh, attention])

        if self.concat:
            return F.leaky_relu(h_prime)
        else:
            return h_prime

    def _prepare_attentional_mechanism_input(self, Wh, batchsize):
        N = Wh.size()[1]
        Wh_repeated_in_chunks = Wh.repeat_interleave(N, dim=1)
        Wh_repeated_alternating = Wh.repeat(1, N, 1)
        all_combinations_matrix = torch.cat([Wh_repeated_in_chunks, Wh_repeated_alternating], dim=2)
        return all_combinations_matrix.view(batchsize, N, N, 2 * self.out_features)

    def __repr__(self):
        return self.__class__.__name__ + ' (' + str(self.in_features) + ' -> ' + str(self.out_features) + ')'


class LayerNorm(nn.Module):
    def __init__(self, num_features, eps=1e-05, elementwise_affine=True):
        super(LayerNorm, self).__init__()

        self.LayerNorm = nn.LayerNorm(num_features, eps, elementwise_affine)

    def forward(self, x):
        x = self.LayerNorm(x)
        return x


class Generator(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout, alpha, nheads):
        super(Generator, self).__init__()
        self.dropout = dropout

        self.attentions1 = [GraphAttentionLayer(nfeat, nhid, dropout=dropout, alpha=alpha, batchsize=32, concat=True)
                            for _ in
                            range(nheads)]
        for i, attention in enumerate(self.attentions1):
            self.add_module('attention_{}'.format(i), attention)

        self.out_att1 = GraphAttentionLayer(nhid * nheads, nclass, dropout=dropout, alpha=alpha, batchsize=32,
                                            concat=False)

        self.attentions2 = [GraphAttentionLayer(nfeat, nhid, dropout=dropout, alpha=alpha, batchsize=32, concat=True)
                            for _ in
                            range(nheads)]
        for i, attention in enumerate(self.attentions2):
            self.add_module('attention_{}'.format(i), attention)

        self.out_att2 = GraphAttentionLayer(nhid * nheads, nclass, dropout=dropout, alpha=alpha, batchsize=32,
                                            concat=False)

        self.weight = Parameter(torch.FloatTensor([0.0, 0.0, 0.0, 0.0]))
        self.LayerNorm = LayerNorm([nhid, nclass])

        self.gc1_1 = GraphConvolution(nfeat, int(nfeat * 2))
        self.LayerNorm1_1 = LayerNorm([nfeat, int(nfeat * 2)])
        self.gc1_2 = GraphConvolution(int(nfeat * 2), nfeat)
        self.LayerNorm1_2 = LayerNorm([nfeat, nfeat])

        self.gc2_1 = GraphConvolution(nfeat, int(nfeat / 2))
        self.LayerNorm2_1 = LayerNorm([nfeat, int(nfeat / 2)])
        self.gc2_2 = GraphConvolution(int(nfeat / 2), nfeat)
        self.LayerNorm2_2 = LayerNorm([nfeat, nfeat])

    def forward(self, adj, feature, batchsize, isTest=False):
        # GAT
        x1 = F.dropout(feature, self.dropout, training=self.training)
        x1 = torch.cat([att(x1, adj, batchsize) for att in self.attentions1], dim=2)
        x1 = F.dropout(x1, self.dropout, training=self.training)
        x1 = self.out_att1(x1, adj, batchsize)
        x1 = self.LayerNorm(x1)
        x1 = F.leaky_relu(x1, 0.05, inplace=True)

        x2 = F.dropout(feature, self.dropout, training=self.training)
        x2 = torch.cat([att(x2, adj, batchsize) for att in self.attentions2], dim=2)
        x2 = F.dropout(x2, self.dropout, training=self.training)
        x2 = self.out_att2(x2, adj, batchsize)
        x2 = self.LayerNorm(x2)
        x2 = F.leaky_relu(x2, 0.05, inplace=True)

        x3 = self.gc1_1(feature, adj)
        x3 = self.LayerNorm1_1(x3)
        x3 = F.leaky_relu(x3, 0.05, inplace=True)
        x3 = self.gc1_2(x3, adj)
        x3 = self.LayerNorm1_2(x3)
        x3 = F.leaky_relu(x3, 0.05, inplace=True)

        x4 = self.gc2_1(feature, adj)
        x4 = self.LayerNorm2_1(x4)
        x4 = F.leaky_relu(x4, 0.05, inplace=True)
        x4 = self.gc2_2(x4, adj)
        x4 = self.LayerNorm2_2(x4)
        x4 = F.leaky_relu(x4, 0.05, inplace=True)

        x = self.weight[0] * x1 + self.weight[1] * x2 + self.weight[2] * x3 + self.weight[3] * x4
        outputs = x + torch.transpose(x, 1, 2)
        outputs = outputs.clamp(0, 1)

        if isTest is True:
            return outputs.squeeze().unsqueeze(0)
        else:
            return outputs.squeeze()


class BatchNorm(nn.Module):
    def __init__(self, num_features, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True):
        super(BatchNorm, self).__init__()

        self.batchnorm_layer = nn.BatchNorm1d(num_features, eps, momentum, affine, track_running_stats)

    def forward(self, x):
        x = x.permute(0, 2, 1)
        x = self.batchnorm_layer(x)
        x = x.permute(0, 2, 1)
        return x


class BatchNormLinear(nn.Module):
    def __init__(self, num_features, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True):
        super(BatchNormLinear, self).__init__()

        self.batchnorm_layer = nn.BatchNorm1d(num_features, eps, momentum, affine, track_running_stats)

    def forward(self, x):
        x = self.batchnorm_layer(x)
        return x


class GraphConvolution(Module):

    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input, adj):
        support = torch.matmul(input, self.weight)
        output = torch.einsum('bij,bjd->bid', [adj, support])
        if self.bias is not None:
            return output + self.bias
        else:
            return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'


class Discriminator(nn.Module):
    def __init__(self, in_feature, out1_feature, out2_feature, out3_feature, dropout):
        super(Discriminator, self).__init__()

        self.gc1 = GraphConvolution(in_feature, out1_feature)
        self.batchnorm1 = BatchNorm(out1_feature)
        self.gc2 = GraphConvolution(out1_feature, out2_feature)
        self.batchnorm2 = BatchNorm(out2_feature)
        self.gc3 = GraphConvolution(out2_feature, out3_feature)
        self.batchnorm3 = BatchNorm(out3_feature)
        self.batchnorm4 = BatchNormLinear(1024)
        self.dropout = dropout
        self.Linear1 = nn.Linear(out3_feature * in_feature, 1024) # 148 for atlas1 and 68 for atlas2
        self.dropout = dropout
        self.Linear2 = nn.Linear(1024, 1)


    def batch_eye(self, size):
        batch_size = size[0]
        n = size[1]
        I = torch.eye(n).unsqueeze(0)
        I = I.repeat(batch_size, 1, 1)
        return I

    def forward(self, adj_matrix, batchSize, isTest=False):
        x = self.batch_eye(adj_matrix.shape).to(adj_matrix.device).float()

        x = self.gc1(x, adj_matrix)
        x = nn.LeakyReLU(0.2, True)(x)
        x = self.batchnorm1(x)

        x = self.gc2(x, adj_matrix)
        x = nn.LeakyReLU(0.2, True)(x)
        x = self.batchnorm2(x)

        x = self.gc3(x, adj_matrix)
        x = nn.LeakyReLU(0.2, True)(x)

        x = F.dropout(x, self.dropout, training=self.training)
        x = x.contiguous().view(batchSize, -1)
        x = self.Linear1(x)
        x = nn.LeakyReLU(0.2, True)(x)

        x = F.dropout(x, self.dropout, training=self.training)
        x = self.Linear2(x)
        x = torch.sigmoid(x)
        x = x.contiguous().view(batchSize, -1)
        outputs = x
        return outputs.squeeze()
