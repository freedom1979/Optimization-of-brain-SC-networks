import torch


def Pearson_loss_regions(gen, real):
    batch = gen.shape[0]
    loss = 0.0
    eps = 1e-6
    for i in range(batch):
        region_num = gen[i].shape[0]
        for region in range(region_num):
            gen_vec = gen[i][region].to(gen.device)
            real_vec = real[i][region].to(gen.device)
            gen_mean = gen_vec - torch.mean(gen_vec) + eps
            real_mean = real_vec - torch.mean(real_vec) + eps
            r_num = torch.sum(gen_mean * real_mean)
            r_den = torch.sqrt(torch.sum(torch.pow(gen_mean, 2)) * torch.sum(torch.pow(real_mean, 2)))
            pear = r_num / r_den
            # pear_official = signal_corelation(gen_vec.numpy(), real_vec.numpy())
            # print pear, pear_official
            loss = loss + torch.pow(pear - 1.0, 2)
            # print loss
    loss = torch.div(loss, float(batch))
    return loss


def Pearson_loss_whole(gen, real):
    batch = gen.shape[0]
    loss = 0.0
    eps = 1e-6
    rate = 1.0
    for i in range(batch):
        gen_vec = gen[i].view(-1).to(gen.device)
        real_vec = real[i].view(-1).to(gen.device)
        gen_mean = gen_vec - torch.mean(gen_vec) + eps
        real_mean = real_vec - torch.mean(real_vec) + eps
        r_num = torch.sum(gen_mean * real_mean)
        r_den = torch.sqrt(torch.sum(torch.pow(gen_mean, 2)) * torch.sum(torch.pow(real_mean, 2)))
        pear = r_num / r_den
        loss = loss + torch.pow(pear - 1.0, 2)
    loss = torch.div(loss, float(batch)) * rate
    return loss
