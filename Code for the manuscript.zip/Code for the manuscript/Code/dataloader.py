import torch.utils.data as data
import os
import random
import os.path
import numpy as np
import torch

import pdb

def adj_matrix_normlize(adj):
    adj_log = adj + 1
    adj_log = np.log2(adj_log)
    return adj_log


def norm(adj):
    maxItem = abs(adj).max()
    return adj / maxItem


def load_data(data_path):
    subjects = [sub for sub in os.listdir(data_path) if not sub.startswith('.')]

    data = []

    for subject in subjects:
        adj_matrix_path = data_path + '/' + subject + '/' + 'common_fiber_matrix.txt'
        func_matrix_path = data_path + '/' + subject + '/' + 'pcc_fmri_feature_matrix_0.txt'
        data.append((subject, adj_matrix_path, func_matrix_path))
    random.shuffle(data)
    return data


def normlize_data(data):
    eps = 1e-9
    all_funcs = []
    all_adjs = []
    for index in range(len(data)):
        subject, adj_matrix_path, func_matrix_path = data[index]

        adj_matrix = np.loadtxt(adj_matrix_path)
        adj_matrix = adj_matrix_normlize(adj_matrix)
        func_matrix = np.loadtxt(func_matrix_path)


        all_adjs.append(adj_matrix)
        all_funcs.append(func_matrix)

    all_adjs = np.stack(all_adjs)
    all_funcs = np.stack(all_funcs)

    adj_mean = all_adjs.mean((0, 1, 2), keepdims=True).squeeze(0)
    adj_std = all_adjs.std((0, 1, 2), keepdims=True).squeeze(0)

    func_mean = all_funcs.mean((0, 1, 2), keepdims=True).squeeze(0)
    func_std = all_funcs.std((0, 1, 2), keepdims=True).squeeze(0)

    return (torch.from_numpy(adj_mean) + eps, torch.from_numpy(adj_std) + eps, torch.from_numpy(func_mean) + eps,
            torch.from_numpy(func_std) + eps)


class MICCAI(data.Dataset):
    def __init__(self, data_path, all_data, data_mean, train=True, test=False):
        self.data_path = data_path
        self.train = train  # training set or val set
        self.test = test
        self.adj_mean, self.adj_std, self.feat_mean, self.feat_std = data_mean

        if self.train:
            self.data = all_data[:1448]
        elif not test:
            self.data = all_data[1448:]
        else:
            test_data = load_data(data_path=data_path)
            self.data = test_data[0:]

        random.shuffle(self.data)

    def __getitem__(self, index):
        subject, adj_matrix_path, func_matrix_path = self.data[index]
        adj_matrix = np.loadtxt(adj_matrix_path)
        adj_matrix = norm(adj_matrix)
        func_matrix = np.loadtxt(func_matrix_path)
        func_matrix = norm(func_matrix)
        adj_matrix = torch.from_numpy(adj_matrix)
        func_matrix = torch.from_numpy(func_matrix)
        return subject, adj_matrix, func_matrix

    def debug_getitem__(self, index=0):
        subject, adj_matrix_path, func_matrix_path = self.data[index]

        adj_matrix = np.loadtxt(adj_matrix_path)
        adj_matrix = adj_matrix_normlize(adj_matrix)

        func_matrix = np.loadtxt(func_matrix_path)

        adj_matrix = torch.from_numpy(adj_matrix)
        func_matrix = torch.from_numpy(func_matrix)

        pdb.set_trace()

        return subject, adj_matrix, func_matrix

    def __len__(self):
        return len(self.data)


def get_loader(data_path, all_data, data_mean, training, test, batch_size=16, num_workers=4):
    dataset = MICCAI(data_path, all_data, data_mean, training, test)

    data_loader = torch.utils.data.DataLoader(dataset=dataset,
                                              batch_size=batch_size,
                                              num_workers=num_workers)

    return data_loader


if __name__ == '__main__':
    data_path = './data'
    subjects = [sub for sub in os.listdir(data_path) if not sub.startswith('.')]
    all_adjs = []
    for subject in subjects:
        adj_matrix_path = data_path + '/' + subject + '/' + 'common_fiber_matrix.txt'
        adj_matrix = np.loadtxt(adj_matrix_path)
        adj_matrix = adj_matrix_normlize(adj_matrix)
        adj_matrix = torch.from_numpy(adj_matrix)

        all_adjs.append(adj_matrix)
    all_adjs = np.stack(all_adjs)
    print(all_adjs)
