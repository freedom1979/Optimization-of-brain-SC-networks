import argparse
import time
import torch
from dataloader import get_loader, load_data, normlize_data
from model import Discriminator, Generator
from utils import *

from tensorboardX import SummaryWriter
import shutil
import pdb
from loss import Pearson_loss_regions, Pearson_loss_whole


def test(args, data_loader, test_generator, test_discriminator, adversarial_loss, writer, epoch, exp_num, device):
    if os.path.exists(args.results_path + '/' + str(exp_num)):
        shutil.rmtree(args.results_path + '/' + str(exp_num))
    os.makedirs(args.results_path + '/' + str(exp_num))
    # Evaluate the models
    test_generator.load_state_dict(torch.load(os.path.join(args.model_path, 'GAN_generator-{}.ckpt'.format(exp_num))), strict=False)
    test_generator.eval()

    test_discriminator.load_state_dict(
        torch.load(os.path.join(args.model_path, 'GAN_discriminator-{}.ckpt'.format(exp_num))), strict=False)
    test_discriminator.eval()

    batch_time = AverageMeter()
    data_time = AverageMeter()
    G_losses = AverageMeter()
    D_losses = AverageMeter()
    real_losses = AverageMeter()
    fake_losses = AverageMeter()
    D_top5accs = AverageMeter()
    gen_top5accs = AverageMeter()
    real_top5accs = AverageMeter()
    fake_top5accs = AverageMeter()

    start = time.time()
    for i, (subject, adj_matrix, func_matrix) in enumerate(data_loader):
        batchSize = adj_matrix.shape[0]

        data_time.update(time.time() - start)

        funcs = func_matrix.to(device).float()
        adjs_real = adj_matrix.to(device).float()

        valid = torch.ones((adjs_real.size(0),), dtype=torch.float).to(device)
        fake = torch.zeros((adjs_real.size(0),), dtype=torch.float).to(device)

        adjs_gen = test_generator(funcs, funcs, batchSize, isTest=True)

        if epoch > 1:
            topo = adjs_gen
            adjs_gen = test_generator(topo, funcs, batchSize, isTest=True)

        adjs_gen_final = adjs_gen.squeeze().cpu().detach().numpy()
        np.savetxt(args.results_path + '/' + str(1) + '/' + subject[0] + '_adjs_gen_' + str(exp_num) + '.txt',
                   adjs_gen_final, fmt='%.9f')

        np.savetxt(args.results_path + '/' + str(1) + '/' + subject[0] + '_adjs_real_' + str(exp_num) + '.txt',
                   adjs_real.squeeze().cpu().detach().numpy(), fmt='%.9f')

        # Forward, backward and optimize
        with torch.no_grad():
            score_real = test_discriminator(adjs_real, batchSize)
            score_fake = test_discriminator(adjs_gen.detach(), batchSize)
            g_score = test_discriminator(adjs_gen, batchSize)
            g_loss = adversarial_loss(g_score.view(-1), valid) + torch.nn.functional.mse_loss(adjs_gen, adjs_real) * args.nodes + Pearson_loss_regions(adjs_gen, adjs_real) + Pearson_loss_whole(adjs_gen, adjs_real)
            real_loss = adversarial_loss(score_real.view(-1), valid)
            fake_loss = adversarial_loss(score_fake.view(-1), fake)
            d_loss = (real_loss + fake_loss) * 0.5

        real_acc = float((score_real.view(-1) > 0.5).sum().item()) / float(batchSize)
        fake_acc = float((score_fake.view(-1) < 0.5).sum().item()) / float(batchSize)
        D_acc = (real_acc + fake_acc) / 2.0
        gen_acc = float((g_score.view(-1) >= 0.5).sum().item()) / float(batchSize)

        G_losses.update(g_loss.item())
        D_losses.update(d_loss.item())
        real_losses.update(real_loss.item())
        fake_losses.update(fake_loss.item())

        real_top5accs.update(real_acc)
        fake_top5accs.update(fake_acc)
        D_top5accs.update(D_acc)
        gen_top5accs.update(gen_acc)
        batch_time.update(time.time() - start)

        start = time.time()

    print('Test Epoch: [{0}/{1}]\t'
          'Batch Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
          'G_Loss {G_loss.val:.4f} ({G_loss.avg:.4f})\t'
          'D_Loss {D_loss.val:.4f} ({D_loss.avg:.4f})\t'
          'Gen Accuracy {gen_top5.val:.3f} ({gen_top5.avg:.3f})\t'
          'Real Accuracy {real_top5.val:.3f} ({real_top5.avg:.3f})\t'
          'Fake Accuracy {fake_top5.val:.3f} ({fake_top5.avg:.3f})'.format(len(data_loader), len(data_loader),
                                                                           batch_time=batch_time,
                                                                           G_loss=G_losses,
                                                                           D_loss=D_losses,
                                                                           gen_top5=gen_top5accs,
                                                                           real_top5=real_top5accs,
                                                                           fake_top5=fake_top5accs, ))
    return D_top5accs.avg


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path', type=str, default='/', help='path for data')
    parser.add_argument('--model_path', type=str, default='/', help='path for saving trained models')
    parser.add_argument('--results_path', type=str, default='./results', help='path for generased adjs')
    parser.add_argument('--middle_results_path', type=str, default='./middle_results', help='path for generased middle adjs')
    parser.add_argument('--runs_path', type=str, default='./runs', help='path for runs')

    parser.add_argument('--log_step', type=int, default=10, help='step size for prining log info')

    parser.add_argument('--nodes', type=int, default=132, help='number of regions, 132 or 62')
    parser.add_argument('--input_size', type=int, default=132, help='dimension of input feature, 132 or 62')
    parser.add_argument('--out1_feature', type=int, default=132, help='dimension of discriminator gcn1, 132 or 62')
    parser.add_argument('--out2_feature', type=int, default=256, help='dimension of discriminator gcn2, 256')
    parser.add_argument('--out3_feature', type=int, default=132, help='dimension of discriminator gcn3, 132 or 62')

    parser.add_argument('--num_epochs', type=int, default=1000)
    parser.add_argument('--pre_epochs', type=int, default=200)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--num_workers', type=int, default=8)
    parser.add_argument('--learning_rate', type=float, default=0.001)
    parser.add_argument('--beta1', type=float, default=0.5)
    parser.add_argument('--beta2', type=float, default=0.999)
    parser.add_argument('--weight_decay', type=float, default=0.01)
    parser.add_argument('--patience', type=float, default=10)

    parser.add_argument('-gpu_id', '--gpu_id', type=int, default=0)

    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    test_generator = Generator(nfeat=args.input_size, nhid=args.input_size, nclass= args.input_size, dropout=0.6, alpha=0.2, nheads=8).to(device)
    test_discriminator = Discriminator(args.input_size, args.out1_feature, args.out2_feature, args.out3_feature,
                                       0.6).to(device)

    all_data = load_data(args.data_path)
    data_mean = normlize_data(all_data)
    adversarial_loss = torch.nn.BCELoss()

    test_data_loader = get_loader(args.data_path, all_data, data_mean, False, True, 1,
                                  num_workers=args.num_workers)
    test_prec = test(args, test_data_loader, test_generator, test_discriminator, adversarial_loss, writer=0, epoch=1000,
                     exp_num=0, device=device)
