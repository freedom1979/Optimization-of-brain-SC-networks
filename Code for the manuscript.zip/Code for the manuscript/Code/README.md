# Can functional connectivity be used to refine structural connectivity strength by combining neural computational model and generative adversarial network?

### Framework:

![1710724343900](image/README/1710724343900.png)

### Code:

#### dataloader.py

This file includes the preprocessing and normalization operations of the data.

#### model.py

Three-layer GCN is used as the discriminator.

Two multi-head GAT and two-layer GCN are combine as the generator of GAN.

#### loss.py

In the proposed GAN, the generator generates SC that can fool the discriminator by extracting the mapping patterns between FC and SC, while the discriminator only needs to compare and distinguish between real and inferred SC. Without a suitable loss function, the generative adversarial loss would be close to 0, resulting in zero backpropagated gradients in the generator. In this study, we referred to the loss function cited in the paper to train our GAN, which consists of three parts: mean squared error (MSE) loss, Pearson’s correlation coefficient(PCC) loss, and GAN loss.

#### train.py

You need to run this file to start. All the hyper-parameters can be defined in this file.

Run `python ./train.py`.

Tested with:

- PyTorch 1.10.0
- Python 3.8.0

### Data:

We conducted our experiments using these two datasets: AOMIC, and ADNI. 536 subjects were used for training and validating. The testing subjects include 100 subjects from AOMIC dataset and 299 subjects (100 HCs, 101 MCIs, and 98 ADs) from ADNI dataset. 
